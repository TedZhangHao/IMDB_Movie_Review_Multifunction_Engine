import torch
class Config:
    vocab_path = "vocab.json"
    glove_path = "glove.6B.300d.txt"
    train_file = "tripadvisor_dmiln_train_split.jsonl"
    val_file = "tripadvisor_dmiln_dev_split.jsonl"
    model_save_path = "best_model.pt"
    batch_size = 512
    lr = 1e-2
    num_epochs = 100
    vocab_size = 50000
    embed_dim = 300
    hidden_size = 200
    num_classes = 3
    alpha = 0.999
    beta = 0.1
    gamma = -0.1
    decay = 0.99
    margin = 0.7
    lambda_asp = 0
    device = "cuda" if torch.cuda.is_available() else "cpu"
