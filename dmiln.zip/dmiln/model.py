import torch
import torch.nn as nn
import torch.nn.functional as F

class DMILN(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.embedding = nn.Embedding(config.vocab_size, config.embed_dim)

        self.aspect_mlp = nn.Linear(config.embed_dim, config.embed_dim)
        self.aspect_attn = nn.Linear(config.embed_dim, 1)

        self.convs = nn.ModuleList([
            nn.Conv1d(config.embed_dim, config.hidden_size, K, padding=K//2)
            for K in [3, 5, 7]
        ])

        self.bilinear_attn = nn.Bilinear(600, config.embed_dim, 1)

        self.sentiment_classifier = nn.Linear(600, config.num_classes)

        self.aspect_importance_attn = nn.Sequential(
            nn.Linear(1200, config.hidden_size),
            nn.Tanh()
        )
        self.v = nn.Linear(config.hidden_size, 1)

    def encode_aspect(self, aspect_keywords_emb):
        B, J, K, D = aspect_keywords_emb.size()
        h = torch.tanh(self.aspect_mlp(aspect_keywords_emb))
        weights = self.aspect_attn(h).squeeze(-1)
        weights = F.softmax(weights, dim=-1)
        aspect_repr = torch.sum(weights.unsqueeze(-1) * h, dim=2)
        return aspect_repr

    def encode_document(self, doc_emb):
        doc_emb = doc_emb.transpose(1, 2)
        conv_outputs = [F.relu(conv(doc_emb)) for conv in self.convs]
        conv_cat = torch.cat(conv_outputs, dim=1)
        doc_features = conv_cat.transpose(1, 2)
        return doc_features

    def aspect_attention(self, doc_features, aspect_repr):
        B, L, H = doc_features.shape
        J = aspect_repr.size(1)
        scores = torch.zeros(B, J, L, device=doc_features.device)
        for j in range(J):
            a = aspect_repr[:, j, :]
            s = self.bilinear_attn(doc_features, a.unsqueeze(1).expand(-1, L, -1)).squeeze(-1)
            scores[:, j] = s
        alpha = F.softmax(scores, dim=-1)
        return alpha

    def forward(self, doc_input_ids, aspect_keyword_ids):
        doc_emb = self.embedding(doc_input_ids)
        aspect_emb = self.embedding(aspect_keyword_ids)

        aspect_repr = self.encode_aspect(aspect_emb)
        doc_features = self.encode_document(doc_emb)

        attn_weights = self.aspect_attention(doc_features, aspect_repr)
        aspect_vectors = torch.einsum('bjl,blh->bjh', attn_weights, doc_features)

        aspect_logits = self.sentiment_classifier(aspect_vectors)
        aspect_probs = F.softmax(aspect_logits, dim=-1)

        doc_repr = torch.mean(aspect_vectors, dim=1)
        fusion = torch.cat([aspect_vectors, doc_repr.unsqueeze(1).expand(-1, aspect_vectors.size(1), -1)], dim=-1)
        aspect_importance = self.v(self.aspect_importance_attn(fusion)).squeeze(-1)
        beta = F.softmax(aspect_importance, dim=-1)

        doc_probs = torch.einsum('bjc,bj->bc', aspect_probs, beta)

        return {
            "aspect_probs": aspect_probs, # 每个 aspect 的预测
            "doc_probs": doc_probs,        # 融合后的最终文档预测
            "attn_weights": attn_weights   # 每个方面的 attention
        }
