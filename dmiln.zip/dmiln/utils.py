import numpy as np
import torch

def load_glove_embeddings(glove_path, vocab, embed_dim=300):
    embeddings = np.random.normal(0, 0.1, (len(vocab), embed_dim)).astype(np.float32)
    found = 0

    with open(glove_path, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) != embed_dim + 1:
                continue
            word = parts[0]
            if word in vocab:
                idx = vocab[word]
                embeddings[idx] = np.array(parts[1:], dtype=np.float32)
                found += 1

    # print(f"Loaded {found}/{len(vocab)} words from GloVe")
    return torch.tensor(embeddings)
