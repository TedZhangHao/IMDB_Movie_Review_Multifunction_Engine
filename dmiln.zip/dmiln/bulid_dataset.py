import os
import json
import glob
import nltk
nltk.download("punkt")
from nltk.tokenize import sent_tokenize

ASPECTS = ["Rooms", "Service", "Cleanliness", "Location", "Value", "Sleep Quality"]
ASPECT_KEYWORDS = {
    "rooms": ["room", "bed", "suite", "bathroom"],
    "service": ["staff", "service", "front desk", "reception"],
    "cleanliness": ["clean", "dirty", "spotless", "filthy"],
    "location": ["location", "area", "place", "neighborhood"],
    "value": ["price", "worth", "value", "cost"],
    "sleep q buality": ["sleep", "quiet", "noise", "comfortable"]
}

def score_to_label(score: float) -> int:
    if score >= 4.0:
        return 2  # 积极
    elif score <= 2.0:
        return 0  # 消极
    else:
        return 1  # 中性

def load_tripadvisor_folder(json_folder):
    json_files = glob.glob(os.path.join(json_folder, "*.json"))
    all_data = []

    for file in json_files:
        with open(file, encoding='utf-8') as f:
            try:
                hotel = json.load(f)
            except Exception:
                continue

            reviews = hotel.get("Reviews", [])
            for review in reviews:
                content = review.get("Content", "")
                ratings = review.get("Ratings", {})
                overall = ratings.get("Overall")
                if not overall or not content.strip():
                    continue

                overall_score = float(overall)
                overall_label = score_to_label(overall_score)

                sent_texts = sent_tokenize(content)
                aspect_labels = {}
                for asp in ASPECTS:
                    score = ratings.get(asp)
                    if score:
                        score = float(score)
                        label = score_to_label(score)
                        aspect_labels[asp.lower()] = label

                if not aspect_labels:
                    continue

                all_data.append({
                    "text": content,
                    "sentences": sent_texts,
                    "label": overall_label,
                    "aspect_labels": aspect_labels,
                    "aspects": {asp.lower(): ASPECT_KEYWORDS[asp] for asp in ASPECT_KEYWORDS}
                })

    return all_data

def save_jsonl(data, path):
    with open(path, "w", encoding="utf-8") as f:
        for item in data:
            json.dump(item, f, ensure_ascii=False)
            f.write("\n")

if __name__ == "__main__":
    data = load_tripadvisor_folder("TripAdvisorJson/json/")
    save_jsonl(data, "tripadvisor_dmiln_train.jsonl")
    print(f"Saved {len(data)} examples to tripadvisor_dmiln_train.jsonl")
