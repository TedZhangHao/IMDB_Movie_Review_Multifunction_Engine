import json
import random

input_path = "tripadvisor_dmiln_train.jsonl"
train_output = "tripadvisor_dmiln_train_split.jsonl"
dev_output = "tripadvisor_dmiln_dev_split.jsonl"
split_ratio = 0.8  # 8:2

# 读取全部数据
with open(input_path, "r", encoding="utf-8") as f:
    data = [json.loads(line.strip()) for line in f if line.strip()]

# 打乱顺序
random.shuffle(data)

# 分割
split_idx = int(len(data) * split_ratio)
train_data = data[:split_idx]
dev_data = data[split_idx:]

# 写入训练集
with open(train_output, "w", encoding="utf-8") as f:
    for item in train_data:
        f.write(json.dumps(item, ensure_ascii=False) + "\n")

# 写入验证集
with open(dev_output, "w", encoding="utf-8") as f:
    for item in dev_data:
        f.write(json.dumps(item, ensure_ascii=False) + "\n")

print(f"[Done] Total: {len(data)}, Train: {len(train_data)}, Dev: {len(dev_data)}")
