import torch
import torch.nn.functional as F

def kl_divergence(p, q, eps=1e-10):
    q = q + eps
    p = p + eps
    return torch.sum(p * torch.log(p / q), dim=-1)

def compute_textual_regularization(attn_weights, snippet_masks):
    kl = kl_divergence(snippet_masks, attn_weights)
    return kl.mean()

def compute_orthogonal_regularization(attn_weights):
    B, J, L = attn_weights.shape
    loss = 0.0
    for b in range(B):
        A = attn_weights[b]
        prod = torch.matmul(A, A.T)
        off_diag = prod - torch.diag(torch.diag(prod))
        loss += off_diag.pow(2).sum()
    return loss / B

def compute_sentimental_regularization(aspect_probs, label_ids):
    B, J, C = aspect_probs.shape
    losses = []
    for b in range(B):
        label = label_ids[b]
        aspect_dist = aspect_probs[b, :, label]
        mean = aspect_dist.mean()
        var = ((aspect_dist - mean) ** 2).mean()
        losses.append(var)
    return torch.stack(losses).mean()

def compute_hinge_loss(doc_probs, label_ids, margin=0.7):
    B = doc_probs.size(0)
    gt_probs = doc_probs[torch.arange(B), label_ids]
    loss = torch.clamp(margin - gt_probs, min=0.0)
    return loss.mean()

def aspect_ce_loss(aspect_probs, aspect_y):
    """
    aspect_probs: [B, J, 2] softmax 输出
    aspect_y:     [B, J]    真实标签，-1 表示无标签
    """
    B, J, C = aspect_probs.size()
    flat_probs = aspect_probs.view(B * J, C)
    flat_y = aspect_y.view(-1)
    mask = flat_y >= 0
    if mask.sum() == 0:
        return torch.tensor(0.0, device=aspect_probs.device)
    loss = F.nll_loss(torch.log(flat_probs[mask]), flat_y[mask])
    return loss

