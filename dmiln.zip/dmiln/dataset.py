import os
import json
import re
import torch
from torch.utils.data import Dataset
import nltk
nltk.download('punkt')
from nltk.tokenize import sent_tokenize

ASPECTS = ["rooms", "service", "cleanliness", "location", "value", "sleep quality"]
ASPECT_KEYWORDS = {
    "rooms": ["room", "bed", "suite", "bathroom"],
    "service": ["staff", "service", "front desk", "reception"],
    "cleanliness": ["clean", "dirty", "spotless", "filthy"],
    "location": ["location", "area", "place", "neighborhood"],
    "value": ["price", "worth", "value", "cost"],
    "sleep quality": ["sleep", "quiet", "noise", "comfortable"]
}

class SimpleTokenizer:
    def __init__(self, vocab_path=None):
        if vocab_path:
            with open(vocab_path, "r", encoding="utf-8") as f:
                self.vocab = json.load(f)
        else:
            self.vocab = {"<pad>": 0, "<unk>": 1}
        self.inv_vocab = {v: k for k, v in self.vocab.items()}

    def __call__(self, text):
        return re.findall(r'\w+', text.lower())

    def encode(self, tokens):
        return [self.vocab.get(t, self.vocab.get("<unk>", 1)) for t in tokens]

    def decode(self, ids):
        return [self.inv_vocab.get(i, "<unk>") for i in ids]

def generate_snippet_mask(doc_tokens, sentences, aspect_keywords, tokenizer):
    L = len(doc_tokens)
    aspect_list = list(aspect_keywords.keys())
    J = len(aspect_list)  # 始终是 6
    aspect_list = list(ASPECT_KEYWORDS.keys())
    mask = torch.zeros(J, L)
    pointer = 0
    sent_boundaries = []
    for sent in sentences:
        sent_tokens = tokenizer(sent)
        start = pointer
        end = start + len(sent_tokens)
        sent_boundaries.append((start, end))
        pointer = end
    for j, asp in enumerate(aspect_list):
        keywords = [kw.lower() for kw in aspect_keywords[asp]]
        for s_idx, (start, end) in enumerate(sent_boundaries):
            sent_text = " ".join(doc_tokens[start:end]).lower()
            if any(kw in sent_text for kw in keywords):
                mask[j, start:end] = 1.0
    mask = mask / (mask.sum(dim=-1, keepdim=True) + 1e-8)
    return mask

class DMSCDataset(Dataset):
    def __init__(self, data, tokenizer, aspect_vocab, max_len=256, num_keywords=5):
        self.data = data
        self.tokenizer = tokenizer
        self.aspect_vocab = aspect_vocab
        self.max_len = max_len
        self.num_keywords = num_keywords

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        entry = self.data[idx]
        text = entry["text"]
        label = int(entry["label"])
        aspects = entry["aspects"]
        sentences = entry["sentences"]

        doc_tokens = self.tokenizer(text)[:self.max_len]
        doc_ids = torch.tensor(self.tokenizer.encode(doc_tokens))

        aspect_keywords = []
        for asp in self.aspect_vocab:
            kws = aspects.get(asp, [])[:self.num_keywords]
            kws += ["<pad>"] * (self.num_keywords - len(kws))
            ids = [self.tokenizer.vocab.get(k, 1) for k in kws]
            aspect_keywords.append(ids)

        aspect_kw_ids = torch.tensor(aspect_keywords)
        snippet_mask = generate_snippet_mask(doc_tokens, sentences, ASPECT_KEYWORDS, self.tokenizer)
        
        # 构造 aspect-level 标签
        y = torch.full((len(self.aspect_vocab),), -1, dtype=torch.long)
        for asp, lbl in entry.get("aspect_labels", {}).items():
            if asp in self.aspect_vocab:
                idx = self.aspect_vocab.index(asp)
                y[idx] = lbl
        return {
            "doc_ids": doc_ids,
            "aspect_kw_ids": aspect_kw_ids,
            "label": torch.tensor(label),
            "snippet_mask": snippet_mask,
            "aspect_y": y
        }
