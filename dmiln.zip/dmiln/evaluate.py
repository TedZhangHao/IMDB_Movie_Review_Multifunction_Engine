
import datetime
import json
import torch
from collections import Counter
from torch.utils.data import DataLoader, WeightedRandomSampler 
import torch.nn.functional as F
from torch.utils.data import DataLoader
from dataset import DMSCDataset, SimpleTokenizer
from utils import load_glove_embeddings
from model import DMILN
from config import Config
from plot import plot_loss_curve, plot_label_distribution
from loss import aspect_ce_loss, compute_textual_regularization, compute_orthogonal_regularization, compute_sentimental_regularization, compute_hinge_loss
from torch.nn.utils.rnn import pad_sequence

def collate(batch):
    doc_ids = pad_sequence([x["doc_ids"] for x in batch], batch_first=True)
    aspect_kw_ids = torch.stack([x["aspect_kw_ids"] for x in batch])
    label = torch.stack([x["label"] for x in batch])
    max_len = doc_ids.size(1)
    snippet_mask = torch.stack([F.pad(x["snippet_mask"], (0, max_len - x["snippet_mask"].size(1))) for x in batch])
    aspect_y = torch.stack([x["aspect_y"] for x in batch])
    return {
        "doc_ids": doc_ids,
        "aspect_kw_ids": aspect_kw_ids,
        "label": label,
        "snippet_mask": snippet_mask,
        "aspect_y": aspect_y
    }

def compute_total_loss(outputs, label_ids, snippet_masks, step, config):
    aspect_probs = outputs["aspect_probs"]
    doc_probs = outputs["doc_probs"]
    attn_weights = outputs["attn_weights"]

    L_doc = compute_hinge_loss(doc_probs, label_ids, margin=config.margin)
    L_text = compute_textual_regularization(attn_weights, snippet_masks)
    L_ortho = compute_orthogonal_regularization(attn_weights)
    L_senti = compute_sentimental_regularization(aspect_probs, label_ids)

    alpha = config.alpha * (config.decay ** step)
    loss = L_doc + alpha * L_text + config.beta * L_ortho + config.gamma * L_senti

    return loss, {
        "hinge": L_doc.item(),
        "textual_KL": L_text.item(),
        "orthogonal": L_ortho.item(),
        "sentimental_var": L_senti.item(),
        "alpha_decay": alpha
    }

def build_balanced_sampler(labels):
    """
    labels: List[int]  ——  每条训练样本的文档级标签 (0/1/2)
    返回  torch.utils.data.WeightedRandomSampler
    """
    counts = Counter(labels)                 # 每类出现次数
    # w_i = 1 / N_class(label_i)
    weights = torch.tensor([1.0 / counts[l] for l in labels], dtype=torch.float)
    sampler = WeightedRandomSampler(weights, num_samples=len(weights), replacement=True)
    return sampler

def train():
    config = Config()
    lambda_asp = getattr(config, 'lambda_asp', 1.0)

    # 使用自定义词表和 tokenizer
    tokenizer = SimpleTokenizer(config.vocab_path)
    vocab = tokenizer.vocab
    config.vocab_size = len(vocab)

    # 加载 GloVe 初始化的 embedding matrix
    embedding_matrix = load_glove_embeddings(config.glove_path, vocab, embed_dim=config.embed_dim)

    # 加载数据
    with open(config.train_file, encoding="utf-8") as f:
        train_data = [json.loads(line) for line in f]
    with open(config.val_file, encoding="utf-8") as f:
        dev_data = [json.loads(line) for line in f]

    aspect_vocab = ["rooms", "service", "cleanliness", "location", "value", "sleep quality"]
    train_dataset = DMSCDataset(train_data, tokenizer, aspect_vocab)
    dev_dataset = DMSCDataset(dev_data, tokenizer, aspect_vocab)

    train_labels = [ex["label"] for ex in train_data]
    balanced_sampler = build_balanced_sampler(train_labels)

    train_loader = DataLoader(train_dataset, batch_size=config.batch_size,sampler=balanced_sampler, collate_fn=collate,drop_last=True)
    dev_loader = DataLoader(dev_dataset, batch_size=config.batch_size, shuffle=False, collate_fn=collate)

    # 初始化模型并加载 embedding
    model = DMILN(config).to(config.device)
    model.embedding.weight.data.copy_(embedding_matrix)  # 替换默认 embedding 参数
    model.embedding.weight.requires_grad = True  # 可根据需求设置为 False 冻结词向量

    optimizer = torch.optim.Adam(model.parameters(), lr=config.lr)

    best_val_acc = 0.0
    patience = 5               # 连续多少次验证准确率不提升就停止
    epochs_no_improve = 0               # 已经多久没有提升
    loss_list = []
    log_file = open("training_log.txt", "w", encoding="utf-8")

    for step, batch in enumerate(train_loader):
        model.train()
        doc_ids = batch["doc_ids"].to(config.device)
        aspect_kw_ids = batch["aspect_kw_ids"].to(config.device)
        label = batch["label"].to(config.device)
        aspect_y = batch["aspect_y"].to(config.device)
        snippet_mask = batch["snippet_mask"].to(config.device)

        outputs = model(doc_ids, aspect_kw_ids)
        loss, breakdown = compute_total_loss(outputs, label, snippet_mask, step, config)
        L_aspect = aspect_ce_loss(outputs['aspect_probs'], aspect_y)
        loss += lambda_asp * L_aspect

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        loss_list.append(loss.item())

        if step % 10 == 0:
            log_line = f"[{datetime.datetime.now()}] Step {step} | Loss: {loss.item():.4f} | Breakdown: {breakdown}\n"
            print(log_line.strip())
            log_file.write(log_line)

        if step % 50 == 0:
            model.eval()
            correct = total = 0
            correct_asp = 0
            total_asp = 0
            val_loss = 0.0

            with torch.no_grad():
                for val_batch in dev_loader:
                    val_doc_ids = val_batch["doc_ids"].to(config.device)
                    val_aspect_kw_ids = val_batch["aspect_kw_ids"].to(config.device)
                    val_label = val_batch["label"].to(config.device)
                    val_snippet_mask = val_batch["snippet_mask"].to(config.device)
                    val_aspect_y = val_batch["aspect_y"].to(config.device)

                    val_outputs = model(val_doc_ids, val_aspect_kw_ids)
                    val_loss_step, _ = compute_total_loss(val_outputs, val_label, val_snippet_mask, step, config)
                    val_loss += val_loss_step.item()

                    pred = torch.argmax(val_outputs["doc_probs"], dim=1)
                    correct += (pred == val_label).sum().item()
                    total += val_label.size(0)

                    pred_asp = torch.argmax(val_outputs["aspect_probs"], dim=-1)
                    mask = val_aspect_y >= 0
                    correct_asp += ((pred_asp == val_aspect_y) & mask).sum().item()
                    total_asp += mask.sum().item()

            val_loss /= len(dev_loader)
            val_acc = correct / total if total > 0 else 0.0

            print(f"[Val] step {step}  loss {val_loss:.4f}  acc {val_acc:.4f}")

            if val_acc > best_val_acc + 1e-4:     # 允许极小浮动
                best_val_acc = val_acc
                epochs_no_improve = 0
                torch.save(model.state_dict(), config.model_save_path)
                print(f"New best acc={val_acc:.4f} model saved.")
            else:
                epochs_no_improve += 1
                print(f"no improve ({epochs_no_improve}/{patience})")

                if epochs_no_improve >= patience:
                    print("Early stopping triggered. Training halted.")
                    break

            log_val = f"[{datetime.datetime.now()}] >> Val Loss: {val_loss:.4f} | Doc Acc: {val_acc:.4f}\n"
            print(log_val.strip())
            log_file.write(log_val)

            if val_acc > best_val_acc:
                best_val_acc = val_acc
                torch.save(model.state_dict(), config.model_save_path)
                print(f">> Best model saved to {config.model_save_path} (acc={val_acc:.4f})")

    log_file.close()
    plot_loss_curve(loss_list)

if __name__ == "__main__":
    # val_file = "tripadvisor_dmiln_dev_split.jsonl"
    # plot_label_distribution(val_file)

    train()
