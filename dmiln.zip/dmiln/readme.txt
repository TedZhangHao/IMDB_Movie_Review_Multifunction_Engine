train.py和evaluate.py中只有训练函数不一样，前者是只包含了早停，后者则增加了amp机制（GradScaler和autocast）
build_vocab.py是根据原始数据的词频统计来构建的词库（vocab.json）
ultils.py是加载GloVe词向量方法的
split.py按8：2划分训练集与验证集
config.py包含用到的参数
loss.py复刻原文中的各种loss
model.py是原文模型复刻
plot.py是可视化图像
词向量文件使用（Glove.6B.300d）符合原文所提及的300维度GloVe词嵌入
build_dataset.py根据overall评分划分成积极，消极和中性
目前所使用数据集是TripAdvisor, 训练后保存的模型就是best_model.pt