import matplotlib.pyplot as plt
import seaborn as sns
import torch
import json
from collections import Counter
import matplotlib.pyplot as plt


def visualize_attention(doc_ids, attn_weights, tokenizer=None, aspect_names=None):
    tokens = [tokenizer.inv_vocab.get(i.item(), "<unk>") for i in doc_ids]
    J = attn_weights.size(0)

    for j in range(J):
        weights = attn_weights[j].detach().cpu().numpy()
        plt.figure(figsize=(12, 1))
        sns.heatmap([weights], xticklabels=tokens, cmap="YlGnBu", cbar=False)
        asp_name = aspect_names[j] if aspect_names else f"aspect {j}"
        plt.title(f"Attention for {asp_name}")
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()

def plot_loss_curve(loss_list, save_path="loss_curve.png", title="Training Loss Curve"):
    """
    绘制 loss 曲线图并保存。

    参数:
    - loss_list (List[float]): 每一步的 loss 数值
    - save_path (str): 图像保存路径
    - title (str): 图像标题
    """
    plt.figure(figsize=(10, 4))
    plt.plot(loss_list, label="Training Loss", color='blue')
    plt.xlabel("Step")
    plt.ylabel("Loss")
    plt.title(title)
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(save_path)
    print(f"[Info] Loss curve saved to: {save_path}")

def plot_label_distribution(json_path):
    labels = []
    with open(json_path, 'r', encoding='utf-8') as f:
        for line in f:
            item = json.loads(line.strip())  # 每行是字符串，需解析为 dict
            labels.append(item["label"])     # 读取 "label" 字段

    label_counter = Counter(labels)
    classes = sorted(label_counter.keys())
    counts = [label_counter[k] for k in classes]

    plt.figure(figsize=(6, 4))
    plt.bar(classes, counts)
    plt.xlabel("Class Label")
    plt.ylabel("Count")
    plt.title("Label Distribution in Validation Set")
    plt.xticks(classes)
    plt.tight_layout()
    plt.show()