
import json
import re
from collections import Counter

def build_vocab_from_json(json_path, min_freq=5, max_size=50000):
    counter = Counter()
    with open(json_path, 'r', encoding='utf-8') as f:
        for line in f:
            item = json.loads(line)
            tokens = re.findall(r'\w+', item['text'].lower())
            counter.update(tokens)

    vocab = {"<pad>": 0, "<unk>": 1}
    for idx, (word, freq) in enumerate(counter.most_common(), start=2):
        if freq < min_freq or len(vocab) >= max_size:
            break
        vocab[word] = idx

    return vocab

if __name__ == "__main__":
    input_path = "tripadvisor_dmiln_train_split.jsonl"   
    output_path = "vocab.json"                           
    min_freq = 5
    max_size = 50000

    vocab = build_vocab_from_json(input_path, min_freq, max_size)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(vocab, f, ensure_ascii=False, indent=2)
    print(f"Saved vocab of size {len(vocab)} to {output_path}")
