
from torch.amp import GradScaler, autocast 
import json
import torch
from collections import Counter
from torch.utils.data import DataLoader, WeightedRandomSampler 
import torch.nn.functional as F
from torch.utils.data import DataLoader
from dataset import DMSCDataset, SimpleTokenizer
from utils import load_glove_embeddings
from model import DMILN
from config import Config
from plot import plot_loss_curve, plot_label_distribution
from loss import aspect_ce_loss, compute_textual_regularization, compute_orthogonal_regularization, compute_sentimental_regularization, compute_hinge_loss
from torch.nn.utils.rnn import pad_sequence

def collate(batch):
    doc_ids = pad_sequence([x["doc_ids"] for x in batch], batch_first=True)
    aspect_kw_ids = torch.stack([x["aspect_kw_ids"] for x in batch])
    label = torch.stack([x["label"] for x in batch])
    max_len = doc_ids.size(1)
    snippet_mask = torch.stack([F.pad(x["snippet_mask"], (0, max_len - x["snippet_mask"].size(1))) for x in batch])
    aspect_y = torch.stack([x["aspect_y"] for x in batch])
    return {
        "doc_ids": doc_ids,
        "aspect_kw_ids": aspect_kw_ids,
        "label": label,
        "snippet_mask": snippet_mask,
        "aspect_y": aspect_y
    }

def compute_total_loss(outputs, label_ids, snippet_masks, step, config):
    aspect_probs = outputs["aspect_probs"]
    doc_probs = outputs["doc_probs"]
    attn_weights = outputs["attn_weights"]

    L_doc = compute_hinge_loss(doc_probs, label_ids, margin=config.margin)
    L_text = compute_textual_regularization(attn_weights, snippet_masks)
    L_ortho = compute_orthogonal_regularization(attn_weights)
    L_senti = compute_sentimental_regularization(aspect_probs, label_ids)

    alpha = config.alpha * (config.decay ** step)
    loss = L_doc + alpha * L_text + config.beta * L_ortho + config.gamma * L_senti

    return loss, {
        "hinge": L_doc.item(),
        "textual_KL": L_text.item(),
        "orthogonal": L_ortho.item(),
        "sentimental_var": L_senti.item(),
        "alpha_decay": alpha
    }

def build_balanced_sampler(labels):
    """
    labels: List[int]  ——  每条训练样本的文档级标签 (0/1/2)
    返回  torch.utils.data.WeightedRandomSampler
    """
    counts = Counter(labels)                 # 每类出现次数
    # w_i = 1 / N_class(label_i)
    weights = torch.tensor([1.0 / counts[l] for l in labels], dtype=torch.float)
    sampler = WeightedRandomSampler(weights, num_samples=len(weights), replacement=True)
    return sampler

def train():
    cfg = Config()
    tok = SimpleTokenizer(cfg.vocab_path)
    cfg.vocab_size = len(tok.vocab)

    # ---- GloVe 初始化 ----
    glove_matrix = load_glove_embeddings(cfg.glove_path, tok.vocab, cfg.embed_dim)

    # ---- 读数据 + DataLoader（带重采样）----
    train_json = [json.loads(l) for l in open(cfg.train_file, encoding='utf-8')]
    dev_json = [json.loads(l) for l in open(cfg.val_file  , encoding='utf-8')]

    aspects = ["rooms", "service", "cleanliness", "location", "value", "sleep quality"]
    train_set = DMSCDataset(train_json, tok, aspects)
    dev_set = DMSCDataset(dev_json, tok, aspects)

    sampler = build_balanced_sampler([ex["label"] for ex in train_json])
    train_loader = DataLoader(train_set, cfg.batch_size, sampler=sampler, collate_fn=collate, drop_last=True)
    dev_loader = DataLoader(dev_set , cfg.batch_size, shuffle=False, collate_fn=collate)

    #模型 & 优化器 & LR Scheduler
    model = DMILN(cfg).to(cfg.device)
    model.embedding.weight.data.copy_(glove_matrix)
    model.embedding.weight.requires_grad = True

    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode='max', patience=2, factor=0.5)
    scaler = GradScaler("cuda")                                  #AMP

    #Early-Stopping 参数
    best_acc, no_improve = 0.0, 0
    patience = 5
    loss_curve = []

    for epoch in range(cfg.num_epochs):
        for step, batch in enumerate(train_loader):
            model.train()
            batch = {k: v.to(cfg.device) for k, v in batch.items()}

            with autocast("cuda"):                                   #AMP
                outs = model(batch["doc_ids"], batch["aspect_kw_ids"])
                loss, _ = compute_total_loss(outs, batch["label"], batch["snippet_mask"], step, cfg)
                loss += cfg.lambda_asp * aspect_ce_loss(outs["aspect_probs"], batch["aspect_y"])

            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            opt.zero_grad()

            loss_curve.append(loss.item())

            if (step + 1) % 50 == 0:
                print(f"[Epoch {epoch+1:02d} | {step+1:04d}] train-loss {loss.item():.4f}")

        #每个epoch结束做一次验证
        model.eval()
        correct = total = 0
        with torch.no_grad():
            for vb in dev_loader:
                vb = {k: v.to(cfg.device) for k, v in vb.items()}
                outs = model(vb["doc_ids"], vb["aspect_kw_ids"])
                pred = outs["doc_probs"].argmax(dim=1)
                correct += (pred == vb["label"]).sum().item()
                total += vb["label"].size(0)

        val_acc = correct / total
        print(f"◆ Epoch {epoch+1}: val-acc = {val_acc:.4f}")
        sched.step(val_acc)                                    # 更新LR

        #Early Stopping
        if val_acc > best_acc + 1e-4:
            best_acc, no_improve = val_acc, 0
            torch.save(model.state_dict(), cfg.model_save_path)
            print(f"new best, model saved ({best_acc:.4f})")
        else:
            no_improve += 1
            if no_improve >= patience:
                print(" Early stopping triggered.")
                break

    plot_loss_curve(loss_curve)

if __name__ == "__main__":
    # val_file = "tripadvisor_dmiln_dev_split.jsonl"
    # plot_label_distribution(val_file)

    train()
